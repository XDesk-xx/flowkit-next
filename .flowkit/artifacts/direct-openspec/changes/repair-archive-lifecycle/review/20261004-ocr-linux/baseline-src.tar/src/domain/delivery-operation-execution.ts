import { createHash } from "node:crypto";
import { lstat, readFile, realpath } from "node:fs/promises";
import path from "node:path";
import { isManagerInstallation } from "../internal/manager-installation.js";

import { isOwnerAuthorityFact, type OwnerAuthorityFact } from "./authority.js";
import {
  isFullTestCheck,
  isFullTestRef,
  type FullTestCheck,
} from "../internal/full-test-input.js";
import { isAttemptId } from "../internal/full-test-storage.js";
import { isSemanticId, type DeliveryId } from "./identity.js";
import { hasNoDuplicates } from "../internal/applicable-check-identity.js";
import {
  cloneDeliveryFinalOperationFacts,
  isDeliveryCoordinationRef,
  type DeliveryCoordinationRef,
  isDeliveryFinalAuthorityForDelivery,
  isDeliveryFinalOperationFactsForDelivery,
  type DeliveryFinalOperationFacts,
} from "./delivery-final-operation.js";
import {
  cloneDeliveryRepositoryIntegrationOperationFacts,
  isRepositoryIntegrationAuthorityForDelivery,
  repositoryIntegrationFactsBelongToDelivery,
  type DeliveryRepositoryIntegrationOperationFacts,
} from "./delivery-repository-integration-operation.js";

export const DELIVERY_OPERATIONS = [
  "delivery-start",
  "delivery-full-test",
  "delivery-final",
  "delivery-repository-integration",
] as const;

export type DeliveryOperationId = (typeof DELIVERY_OPERATIONS)[number];

export function isDeliveryOperationId(
  value: unknown,
): value is DeliveryOperationId {
  return (
    typeof value === "string" &&
    (DELIVERY_OPERATIONS as readonly string[]).includes(value)
  );
}

const DELIVERY_GUIDANCE_PATHS: Readonly<Record<DeliveryOperationId, string>> = {
  "delivery-start": "skills/delivery/start/SKILL.md",
  "delivery-full-test": "skills/delivery/full-test/SKILL.md",
  "delivery-final": "skills/delivery/final/SKILL.md",
  "delivery-repository-integration":
    "skills/delivery/repository-integration/SKILL.md",
};

export function canonicalDeliveryGuidancePath(
  operationId: unknown,
): string | null {
  if (!isDeliveryOperationId(operationId)) return null;
  return DELIVERY_GUIDANCE_PATHS[operationId];
}

export interface DeliveryGuidanceRef {
  readonly path: string;
  readonly contentSha256: string;
}

const GUIDANCE_REF_FIELDS = ["path", "contentSha256"] as const;
const SHA256_HEX_PATTERN = /^[0-9a-f]{64}$/;
const ARTIFACT_PATTERN = /^[!-~]{1,512}$/;

function isRecord(value: unknown): value is Record<string, unknown> {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    return false;
  }
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}

function hasExactlyFields(
  value: Record<string, unknown>,
  fields: readonly string[],
): boolean {
  const keys = Object.keys(value);
  return (
    keys.length === fields.length &&
    fields.every((field) => Object.prototype.hasOwnProperty.call(value, field))
  );
}

function operationIdFromCanonicalGuidancePath(
  value: unknown,
): DeliveryOperationId | null {
  if (typeof value !== "string") return null;
  for (const operationId of DELIVERY_OPERATIONS) {
    if (DELIVERY_GUIDANCE_PATHS[operationId] === value) return operationId;
  }
  return null;
}

export function isDeliveryGuidanceRef(
  value: unknown,
): value is DeliveryGuidanceRef {
  if (!isRecord(value) || !hasExactlyFields(value, GUIDANCE_REF_FIELDS)) {
    return false;
  }
  return (
    operationIdFromCanonicalGuidancePath(value.path) !== null &&
    typeof value.contentSha256 === "string" &&
    SHA256_HEX_PATTERN.test(value.contentSha256)
  );
}

export function isDeliveryGuidanceRefForOperation(
  value: unknown,
  operationId: unknown,
): value is DeliveryGuidanceRef {
  const expectedPath = canonicalDeliveryGuidancePath(operationId);
  return (
    expectedPath !== null &&
    isDeliveryGuidanceRef(value) &&
    value.path === expectedPath
  );
}

async function canonicalGuidanceEntry(
  repositoryRoot: string,
  relativePath: string,
): Promise<{ readonly path: string; readonly bytes: Buffer } | null> {
  try {
    const canonicalRoot = await realpath(repositoryRoot);
    const expectedPath = path.join(canonicalRoot, ...relativePath.split("/"));
    const entry = await lstat(expectedPath);
    if (!entry.isFile() || entry.isSymbolicLink()) return null;

    const resolvedPath = await realpath(expectedPath);
    if (resolvedPath !== expectedPath) return null;

    return { path: expectedPath, bytes: await readFile(expectedPath) };
  } catch {
    return null;
  }
}

export async function resolveDeliveryGuidanceRef(
  installation: unknown,
  operationId: unknown,
): Promise<DeliveryGuidanceRef | null> {
  if (!isManagerInstallation(installation)) {
    return null;
  }

  const relativePath = canonicalDeliveryGuidancePath(operationId);
  if (relativePath === null) return null;
  const entry = await canonicalGuidanceEntry(installation.root, relativePath);
  if (entry === null) return null;

  return {
    path: relativePath,
    contentSha256: createHash("sha256").update(entry.bytes).digest("hex"),
  };
}

export async function readExactDeliveryGuidance(
  installation: unknown,
  guidanceRef: unknown,
): Promise<Buffer | null> {
  if (
    !isManagerInstallation(installation) ||
    !isDeliveryGuidanceRef(guidanceRef)
  ) {
    return null;
  }

  const entry = await canonicalGuidanceEntry(
    installation.root,
    guidanceRef.path,
  );
  if (entry === null) return null;
  const contentSha256 = createHash("sha256").update(entry.bytes).digest("hex");
  return contentSha256 === guidanceRef.contentSha256 ? entry.bytes : null;
}

export interface DeliveryPlanningReference {
  readonly artifact: string;
  readonly contentSha256: string;
}

const PLANNING_REFERENCE_FIELDS = ["artifact", "contentSha256"] as const;

export function isDeliveryPlanningReference(
  value: unknown,
): value is DeliveryPlanningReference {
  if (!isRecord(value) || !hasExactlyFields(value, PLANNING_REFERENCE_FIELDS)) {
    return false;
  }
  return (
    typeof value.artifact === "string" &&
    ARTIFACT_PATTERN.test(value.artifact) &&
    !value.artifact.includes("..") &&
    typeof value.contentSha256 === "string" &&
    SHA256_HEX_PATTERN.test(value.contentSha256)
  );
}

export interface DeliveryStartOperationFacts {
  readonly projectId: string;
  readonly planningReference: DeliveryPlanningReference;
  readonly coordinationPrestate: {
    readonly artifact: string;
    readonly contentRef: DeliveryCoordinationRef | null;
  };
}

const DELIVERY_START_FACT_FIELDS = [
  "projectId",
  "planningReference",
  "coordinationPrestate",
] as const;

export function isDeliveryStartOperationFacts(
  value: unknown,
): value is DeliveryStartOperationFacts {
  if (
    !isRecord(value) ||
    !hasExactlyFields(value, DELIVERY_START_FACT_FIELDS)
  ) {
    return false;
  }
  return (
    isSemanticId(value.projectId) &&
    isDeliveryPlanningReference(value.planningReference) &&
    isRecord(value.coordinationPrestate) &&
    hasExactlyFields(value.coordinationPrestate, ["artifact", "contentRef"]) &&
    typeof value.coordinationPrestate.artifact === "string" &&
    /^openspec\/delivery-groups\/[^/]+\.yaml$/.test(
      value.coordinationPrestate.artifact,
    ) &&
    (value.coordinationPrestate.contentRef === null ||
      (isDeliveryCoordinationRef(value.coordinationPrestate.contentRef) &&
        value.coordinationPrestate.contentRef.artifact ===
          value.coordinationPrestate.artifact))
  );
}

export function isDeliveryStartAuthorityForDelivery(
  value: unknown,
  deliveryId: unknown,
): value is OwnerAuthorityFact {
  return (
    isSemanticId(deliveryId) &&
    isOwnerAuthorityFact(value) &&
    value.deliveryId === deliveryId &&
    value.changeId === undefined &&
    value.decision === "create-delivery" &&
    value.scope.includes("delivery-start")
  );
}

export interface DeliveryFullTestOperationFacts {
  readonly attemptId: string;
  readonly configRef: string;
  readonly inputRef: string;
  readonly orderedChecks: readonly FullTestCheck[];
}

const DELIVERY_FULL_TEST_FACT_FIELDS = [
  "attemptId",
  "configRef",
  "inputRef",
  "orderedChecks",
] as const;

export function isDeliveryFullTestOperationFacts(
  value: unknown,
): value is DeliveryFullTestOperationFacts {
  if (
    !isRecord(value) ||
    !hasExactlyFields(value, DELIVERY_FULL_TEST_FACT_FIELDS) ||
    !isAttemptId(value.attemptId) ||
    !isFullTestRef(value.configRef, "full-test-config") ||
    !isFullTestRef(value.inputRef, "full-test-input") ||
    !Array.isArray(value.orderedChecks) ||
    value.orderedChecks.length < 1 ||
    !value.orderedChecks.every(isFullTestCheck)
  ) {
    return false;
  }
  return (
    hasNoDuplicates(value.orderedChecks.map((check) => check.checkId)) &&
    hasNoDuplicates(value.orderedChecks.map((check) => check.checkRef))
  );
}

export function isFormalFullTestAuthorityForDelivery(
  value: unknown,
  deliveryId: unknown,
): value is OwnerAuthorityFact {
  return (
    isSemanticId(deliveryId) &&
    isOwnerAuthorityFact(value) &&
    value.deliveryId === deliveryId &&
    value.changeId === undefined &&
    value.decision === "authorize-formal-full-test" &&
    value.scope.length === 1 &&
    value.scope[0] === "delivery-full-test"
  );
}

export type DeliveryOperationFacts =
  | DeliveryStartOperationFacts
  | DeliveryFullTestOperationFacts
  | DeliveryFinalOperationFacts
  | DeliveryRepositoryIntegrationOperationFacts;

interface DeliveryOperationPackageBase {
  readonly deliveryId: DeliveryId;
  readonly ownerAuthority: OwnerAuthorityFact | null;
  readonly guidanceRef: DeliveryGuidanceRef;
}

export interface DeliveryStartOperationPackage extends DeliveryOperationPackageBase {
  readonly operationId: "delivery-start";
  readonly operationFacts: DeliveryStartOperationFacts;
}

export interface DeliveryFullTestOperationPackage extends DeliveryOperationPackageBase {
  readonly operationId: "delivery-full-test";
  readonly operationFacts: DeliveryFullTestOperationFacts;
}

export interface DeliveryFinalOperationPackage extends DeliveryOperationPackageBase {
  readonly operationId: "delivery-final";
  readonly ownerAuthority: OwnerAuthorityFact;
  readonly operationFacts: DeliveryFinalOperationFacts;
}

export interface DeliveryRepositoryIntegrationOperationPackage extends DeliveryOperationPackageBase {
  readonly operationId: "delivery-repository-integration";
  readonly ownerAuthority: OwnerAuthorityFact;
  readonly operationFacts: DeliveryRepositoryIntegrationOperationFacts;
}

export type DeliveryOperationPackage =
  | DeliveryStartOperationPackage
  | DeliveryFullTestOperationPackage
  | DeliveryFinalOperationPackage
  | DeliveryRepositoryIntegrationOperationPackage;

const DELIVERY_OPERATION_PACKAGE_FIELDS = [
  "deliveryId",
  "operationId",
  "ownerAuthority",
  "operationFacts",
  "guidanceRef",
] as const;

export function isDeliveryOperationPackage(
  value: unknown,
): value is DeliveryOperationPackage {
  if (
    !isRecord(value) ||
    !hasExactlyFields(value, DELIVERY_OPERATION_PACKAGE_FIELDS)
  ) {
    return false;
  }

  if (!isSemanticId(value.deliveryId)) return false;
  if (!isDeliveryOperationId(value.operationId)) return false;
  if (
    !isDeliveryGuidanceRefForOperation(value.guidanceRef, value.operationId)
  ) {
    return false;
  }

  switch (value.operationId) {
    case "delivery-start":
      return (
        isDeliveryStartOperationFacts(value.operationFacts) &&
        value.operationFacts.coordinationPrestate.artifact ===
          `openspec/delivery-groups/${value.deliveryId}.yaml` &&
        isDeliveryStartAuthorityForDelivery(
          value.ownerAuthority,
          value.deliveryId,
        )
      );
    case "delivery-full-test":
      return (
        isDeliveryFullTestOperationFacts(value.operationFacts) &&
        isFormalFullTestAuthorityForDelivery(
          value.ownerAuthority,
          value.deliveryId,
        )
      );
    case "delivery-final":
      return (
        isDeliveryFinalOperationFactsForDelivery(
          value.operationFacts,
          value.deliveryId,
        ) &&
        isDeliveryFinalAuthorityForDelivery(
          value.ownerAuthority,
          value.deliveryId,
        )
      );
    case "delivery-repository-integration":
      return (
        repositoryIntegrationFactsBelongToDelivery(
          value.operationFacts,
          value.deliveryId,
        ) &&
        isRepositoryIntegrationAuthorityForDelivery(
          value.ownerAuthority,
          value.deliveryId,
        )
      );
  }
}

function clonePlanningReference(
  reference: DeliveryPlanningReference,
): DeliveryPlanningReference {
  return {
    artifact: reference.artifact,
    contentSha256: reference.contentSha256,
  };
}

function cloneStartFacts(
  facts: DeliveryStartOperationFacts,
): DeliveryStartOperationFacts {
  return {
    projectId: facts.projectId,
    planningReference: clonePlanningReference(facts.planningReference),
    coordinationPrestate: {
      artifact: facts.coordinationPrestate.artifact,
      contentRef:
        facts.coordinationPrestate.contentRef === null
          ? null
          : { ...facts.coordinationPrestate.contentRef },
    },
  };
}

function cloneResolvedCheck(check: FullTestCheck): FullTestCheck {
  return {
    checkId: check.checkId,
    program: check.program,
    args: [...check.args],
    cwd: check.cwd,
    toolRef: check.toolRef,
    environmentRefs: [...check.environmentRefs],
    checkRef: check.checkRef,
  };
}

function cloneFullTestFacts(
  facts: DeliveryFullTestOperationFacts,
): DeliveryFullTestOperationFacts {
  return {
    attemptId: facts.attemptId,
    configRef: facts.configRef,
    inputRef: facts.inputRef,
    orderedChecks: facts.orderedChecks.map(cloneResolvedCheck),
  };
}

function cloneAuthority(authority: OwnerAuthorityFact): OwnerAuthorityFact {
  return {
    ref: authority.ref,
    decision: authority.decision,
    deliveryId: authority.deliveryId,
    ...(authority.changeId === undefined
      ? {}
      : { changeId: authority.changeId }),
    sourceRef: authority.sourceRef,
    scope: [...authority.scope],
  };
}

function cloneGuidanceRef(ref: DeliveryGuidanceRef): DeliveryGuidanceRef {
  return { path: ref.path, contentSha256: ref.contentSha256 };
}

export function formDeliveryOperationPackage(
  deliveryId: unknown,
  operationId: unknown,
  ownerAuthority: unknown,
  operationFacts: unknown,
  guidanceRef: unknown,
): DeliveryOperationPackage | null {
  if (!isSemanticId(deliveryId) || !isDeliveryOperationId(operationId)) {
    return null;
  }
  if (!isDeliveryGuidanceRefForOperation(guidanceRef, operationId)) {
    return null;
  }

  if (operationId === "delivery-start") {
    if (!isDeliveryStartOperationFacts(operationFacts)) return null;
    if (!isDeliveryStartAuthorityForDelivery(ownerAuthority, deliveryId)) {
      return null;
    }
    const candidate: DeliveryStartOperationPackage = {
      deliveryId,
      operationId,
      ownerAuthority: cloneAuthority(ownerAuthority),
      operationFacts: cloneStartFacts(operationFacts),
      guidanceRef: cloneGuidanceRef(guidanceRef),
    };
    return isDeliveryOperationPackage(candidate) ? candidate : null;
  }

  if (operationId === "delivery-full-test") {
    if (!isDeliveryFullTestOperationFacts(operationFacts)) return null;
    if (!isFormalFullTestAuthorityForDelivery(ownerAuthority, deliveryId)) {
      return null;
    }
    const candidate: DeliveryFullTestOperationPackage = {
      deliveryId,
      operationId,
      ownerAuthority: cloneAuthority(ownerAuthority),
      operationFacts: cloneFullTestFacts(operationFacts),
      guidanceRef: cloneGuidanceRef(guidanceRef),
    };
    return isDeliveryOperationPackage(candidate) ? candidate : null;
  }

  if (operationId === "delivery-final") {
    if (
      !isDeliveryFinalOperationFactsForDelivery(operationFacts, deliveryId) ||
      !isDeliveryFinalAuthorityForDelivery(ownerAuthority, deliveryId)
    ) {
      return null;
    }
    const candidate: DeliveryFinalOperationPackage = {
      deliveryId,
      operationId,
      ownerAuthority: cloneAuthority(ownerAuthority),
      operationFacts: cloneDeliveryFinalOperationFacts(operationFacts),
      guidanceRef: cloneGuidanceRef(guidanceRef),
    };
    return isDeliveryOperationPackage(candidate) ? candidate : null;
  }

  if (operationId === "delivery-repository-integration") {
    if (
      !repositoryIntegrationFactsBelongToDelivery(operationFacts, deliveryId) ||
      !isRepositoryIntegrationAuthorityForDelivery(ownerAuthority, deliveryId)
    ) {
      return null;
    }
    const candidate: DeliveryRepositoryIntegrationOperationPackage = {
      deliveryId,
      operationId,
      ownerAuthority: cloneAuthority(ownerAuthority),
      operationFacts:
        cloneDeliveryRepositoryIntegrationOperationFacts(operationFacts),
      guidanceRef: cloneGuidanceRef(guidanceRef),
    };
    return isDeliveryOperationPackage(candidate) ? candidate : null;
  }

  return null;
}
