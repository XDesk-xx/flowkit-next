import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";

const root = process.cwd();
const proofRelative = ".flowkit/artifacts/20260929-07-bootstrap-execution-and-skill-hardening/changes/validate-and-freeze-bootstrap-manager/proof/20261001-065-apply";
const proof = path.join(root, proofRelative);
const read = async (name) => JSON.parse(await readFile(path.join(proof, name), "utf8"));
const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
const release = await read("release-package-report.json");
const checks = await read("verified-checks-report.json");
const install = await read("isolated-install-report.json");
const action = await read("installed-actions-report.json");
const support = await read("installed-support-report.json");
const windows = await read("installed-acceptance-report.json");
const audit = await read("installed-byte-audit-report.json");
const linux = await read("linux-acceptance-02-report.json");
assert.ok(checks.checks.every((item) => item.exitCode === 0));
assert.equal(install.packageSha256, release.packageSha256);
assert.equal(action.packageSha256, release.packageSha256);
assert.equal(support.packageSha256, release.packageSha256);
assert.equal(windows.packageSha256, release.packageSha256);
assert.equal(audit.packageSha256, release.packageSha256);
assert.equal(linux.packageSha256, release.packageSha256);
assert.equal(linux.code, 0);
assert.equal(windows.code, 0);
assert.equal(install.doctor.status, "pass");
assert.equal(action.finished.effect, "confirmed");
assert.equal(support.legal.result.status, "completed");
const linuxOutput = (await readFile(path.join(proof, "linux-acceptance-02.stdout.txt"))).toString("utf8");
assert.match(linuxOutput, /Linux x86_64/);
assert.match(linuxOutput, /Debian GLIBC/);
assert.match(linuxOutput, /^# fail 0$/m);
const packageBytes = await readFile(path.join(root, ...release.packagePath.split("/")));
assert.equal(digest(packageBytes), release.packageSha256);
const run = promisify(execFile);
const git = async (...args) => (await run("git", args, { cwd: root, windowsHide: true })).stdout.trim();
const branch = await git("branch", "--show-current");
const head = await git("rev-parse", "HEAD");
assert.equal(branch, checks.source.branch);
assert.equal(head, checks.source.head);
const sourcePaths = ["package.json", "pnpm-lock.yaml", "config/tools/toolchain.lock.json",
  "scripts/check-forbidden-tracked-artifacts.mjs", "tests/unit/quality/owned-source-policy.test.ts",
  "openspec/delivery-groups/20260929-07-bootstrap-execution-and-skill-hardening.yaml",
  "openspec/changes/validate-and-freeze-bootstrap-manager/proposal.md",
  "openspec/changes/validate-and-freeze-bootstrap-manager/design.md"];
const sourceHashes = {};
for (const name of sourcePaths) sourceHashes[name] = digest(await readFile(path.join(root, name)));
const record = {
  kind: "d07-e-release-candidate", deliveryId: "20260929-07-bootstrap-execution-and-skill-hardening",
  changeId: "validate-and-freeze-bootstrap-manager", applyRunId: "20261001-065-apply",
  source: { branch, head, sourceHashes, uncommittedInputs: [
    "scripts/check-forbidden-tracked-artifacts.mjs", "tests/unit/quality/owned-source-policy.test.ts",
    "openspec/delivery-groups/20260929-07-bootstrap-execution-and-skill-hardening.yaml",
    "openspec/changes/validate-and-freeze-bootstrap-manager/" ],
    priorFailedApplyRunId: "20261001-062-apply" },
  package: { name: release.name, version: release.version, path: release.packagePath,
    bytes: release.packageBytes, sha256: release.packageSha256, bin: release.bin,
    dependencies: release.dependencies, memberCount: release.packageMemberCount },
  toolAndSkills: { exactOpenSpec: "@fission-ai/openspec@1.10.0",
    toolLockSha256: sourceHashes["config/tools/toolchain.lock.json"],
    packagedSkillFiles: release.sourceSkillCount, installedByteMatchedFiles: audit.verifiedFileCount },
  installs: { windows: install.manager, linux: `${linux.scratch}/install/node_modules/flowkit-next` },
  evidence: { checks: `${proofRelative}/verified-checks-report.json`, package: `${proofRelative}/release-package-report.json`,
    windowsInstall: `${proofRelative}/isolated-install-report.json`, installedActions: `${proofRelative}/installed-actions-report.json`,
    installedSupport: `${proofRelative}/installed-support-report.json`, installedByteAudit: `${proofRelative}/installed-byte-audit-report.json`,
    windowsAcceptance: `${proofRelative}/installed-acceptance-report.json`, linuxAcceptance: `${proofRelative}/linux-acceptance-02-report.json` },
  scope: { ownerSourceRef: "owner-input:2026-10-01:revise-e-acceptance-scope",
    verified: "Actual tgz, isolated production installs, fixed command fixtures, Windows compatibility simulation, Linux x64 glibc detached acceptance.",
    unverified: "Real independent project use, actual Author/Reviewer correction, new Agent session, host permission prompts.",
    authority: "Candidate record only. Owner Stable selection, Formal Full Test, Delivery Final and Git checkpoint/push/merge remain separate." },
};
await writeFile(path.join(proof, "release-candidate.json"), JSON.stringify(record, null, 2) + "\n", { flag: "wx" });
assert.deepEqual(await read("release-candidate.json"), record);
process.stdout.write(JSON.stringify({ name: record.package.name, version: record.package.version,
  sha256: record.package.sha256, linuxCode: linux.code, installedByteMatchedFiles: audit.verifiedFileCount }) + "\n");
