import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const proof = path.join(root, ".flowkit/artifacts/20260929-07-bootstrap-execution-and-skill-hardening/changes/validate-and-freeze-bootstrap-manager/proof/20261001-065-apply");
const installed = JSON.parse(await readFile(path.join(proof, "isolated-install-report.json"), "utf8"));
const fixture = path.join(installed.scratch, "action-fixture");
const target = path.join(fixture, "target");
const openspec = "C:/Users/xuser/.flowkit/tools/openspec/1.10.0/bin/openspec.js";
const home = "C:/Users/xuser/.flowkit";
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const checks = [];
async function run(id, executable, args, cwd, expectedCode = 0) {
  const start = new Date().toISOString();
  const child = spawn(executable, args, { cwd, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
  const stdout = [], stderr = [];
  child.stdout.on("data", (bytes) => stdout.push(bytes));
  child.stderr.on("data", (bytes) => stderr.push(bytes));
  const outcome = await new Promise((resolve) => {
    child.on("error", (error) => resolve({ code: null, signal: null, error: error.message }));
    child.on("close", (code, signal) => resolve({ code, signal, error: null }));
  });
  const out = Buffer.concat(stdout), err = Buffer.concat(stderr);
  await writeFile(path.join(proof, `${id}.stdout.txt`), out, { flag: "wx" });
  await writeFile(path.join(proof, `${id}.stderr.txt`), err, { flag: "wx" });
  checks.push({ id, command: [executable, ...args], cwd, start, end: new Date().toISOString(), ...outcome,
    stdoutBytes: out.length, stdoutSha256: hash(out), stderrBytes: err.length, stderrSha256: hash(err) });
  assert.equal(outcome.code, expectedCode, `${id}: ${err.toString("utf8")} ${out.toString("utf8")}`);
  const text = out.toString("utf8");
  try { return JSON.parse(text); } catch { return text; }
}
await mkdir(target, { recursive: true });
await run("action-fixture-git-init", "git", ["init", "-b", "main"], target);
await writeFile(path.join(target, ".gitattributes"), ".flowkit/runs/** -text\n.flowkit/artifacts/** -text\n");
await run("action-fixture-openspec-init", process.execPath, [openspec, "init", "--tools", "none"], target);
await run("action-fixture-new-change", process.execPath, [openspec, "new", "change", "change-one"], target);
await mkdir(path.join(target, "openspec/delivery-groups"), { recursive: true });
await writeFile(path.join(target, "openspec/delivery-groups/delivery-one.yaml"), JSON.stringify({
  id: "delivery-one", changes: [{ id: "change-one", state: "active", dependsOn: [], projectOrdinal: 1 }],
  ownerDecisions: [{ ref: `owner:${"a".repeat(64)}`, decision: "activate-change", deliveryId: "delivery-one",
    changeId: "change-one", sourceRef: "synthetic-installed-action-fixture", scope: ["explore"] }],
}) + "\n");
const base = { repositoryRoot: target, flowkitHome: home, deliveryId: "delivery-one", changeId: "change-one" };
const request = async (name, value) => {
  const file = path.join(fixture, `${name}.json`);
  await writeFile(file, JSON.stringify(value) + "\n", { flag: "wx" });
  return file;
};
const query = await request("action-query", base);
const before = await run("action-before-next", process.execPath, [installed.cli, "next", "--input", query], target);
assert.equal(before.decision?.actionId, "explore");
const startInput = await request("action-start-input", { ...base, actionId: "explore", role: "author" });
const conflict = await run("action-conflict", process.execPath, [installed.cli, "action", "start", "--repository-root", installed.target, "--input", startInput], target, 2);
assert.equal(conflict.error?.kind, "invalid-request");
const started = await run("action-start", process.execPath, [installed.cli, "action", "start", "--input", startInput], target);
assert.equal(started.effect, "started");
assert.deepEqual(await readdir(started.directory), ["action.md"]);
const partial = await run("action-partial-next", process.execPath, [installed.cli, "next", "--input", query], target);
assert.equal(partial.decision?.kind, "blocked");
const runId = started.runId;
const proofPath = `.flowkit/artifacts/delivery-one/changes/change-one/proof/${runId}/proof.txt`;
await mkdir(path.dirname(path.join(target, proofPath)), { recursive: true });
const bytes = Buffer.from("synthetic installed action fixture\n");
await writeFile(path.join(target, proofPath), bytes);
const result = { runId, actionIdentity: { deliveryId: "delivery-one", changeId: "change-one", actionId: "explore" },
  authorConclusion: "FAIL", reviewerVerdict: null, verificationVerdict: null, nextBoundary: null,
  facts: { reason: "synthetic fixture stops without a business conclusion", projectOrdinal: 1, proofRefs: [] } };
const missingInput = await request("action-finish-missing-proof", { ...base, runId, role: "author", terminal: true, result });
const missing = await run("action-missing-proof", process.execPath, [installed.cli, "action", "finish", "--input", missingInput], target, 2);
assert.equal(missing.error?.kind, "invalid-request");
assert.deepEqual(await readdir(started.directory), ["action.md"]);
result.facts.proofRefs = [{ path: proofPath, bytes: bytes.length, sha256: hash(bytes), deliveryId: "delivery-one", changeId: "change-one", runId, purpose: "synthetic fixture failure evidence" }];
const finishInput = await request("action-finish-input", { ...base, runId, role: "author", terminal: true, result });
const finished = await run("action-finish", process.execPath, [installed.cli, "action", "finish", "--input", finishInput], target);
assert.equal(finished.effect, "confirmed");
const after = await run("action-after-next", process.execPath, [installed.cli, "next", "--input", query], target);
assert.equal(after.decision?.kind, "blocked");
const report = { kind: "d07-e-installed-fixed-action-fixture", target, manager: installed.manager,
  packageSha256: installed.packageSha256, before, conflict, started, partial, missing, finished, after, checks,
  limitation: "Synthetic fixture only. A terminal FAIL tests persistence; it is not a real business verdict or independent review." };
await writeFile(path.join(proof, "installed-actions-report.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
process.stdout.write(JSON.stringify({ before: before.decision, started: started.effect, partial: partial.decision,
  missing: missing.error, finished: finished.effect, after: after.decision }) + "\n");
