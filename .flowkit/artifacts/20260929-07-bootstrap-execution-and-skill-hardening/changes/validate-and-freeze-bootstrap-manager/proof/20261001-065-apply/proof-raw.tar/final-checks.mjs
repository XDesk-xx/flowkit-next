import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const proof = path.join(root, ".flowkit/artifacts/20260929-07-bootstrap-execution-and-skill-hardening/changes/validate-and-freeze-bootstrap-manager/proof/20261001-065-apply");
const openspec = "C:/Users/xuser/.flowkit/tools/openspec/1.10.0/bin/openspec.js";
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const checks = [];
async function run(id, command, args) {
  const start = new Date().toISOString();
  const child = spawn(command, args, { cwd: root, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
  const stdout = [], stderr = [];
  child.stdout.on("data", (bytes) => stdout.push(bytes));
  child.stderr.on("data", (bytes) => stderr.push(bytes));
  const code = await new Promise((resolve, reject) => { child.on("error", reject); child.on("close", resolve); });
  const out = Buffer.concat(stdout), err = Buffer.concat(stderr);
  await writeFile(path.join(proof, `${id}.stdout.txt`), out, { flag: "wx" });
  await writeFile(path.join(proof, `${id}.stderr.txt`), err, { flag: "wx" });
  checks.push({ id, command: [command, ...args], cwd: root, start, end: new Date().toISOString(), code,
    stdoutBytes: out.length, stdoutSha256: hash(out), stderrBytes: err.length, stderrSha256: hash(err) });
  assert.equal(code, 0, `${id}: ${err.toString("utf8")}`);
}
await run("final-openspec-validate", process.execPath, [openspec, "validate", "validate-and-freeze-bootstrap-manager", "--strict"]);
await run("final-git-diff-check", "git", ["diff", "--check"]);
await run("final-git-status", "git", ["status", "--short"]);
const tasks = await readFile(path.join(root, "openspec/changes/validate-and-freeze-bootstrap-manager/tasks.md"), "utf8");
assert.equal((tasks.match(/^- \[x\]/gm) ?? []).length, 9);
assert.equal((tasks.match(/^- \[ \]/gm) ?? []).length, 0);
const audit = JSON.parse(await readFile(path.join(proof, "installed-byte-audit-report.json"), "utf8"));
for (const item of audit.files) assert.equal(hash(await readFile(path.join(root, item.path))), item.sha256, item.path);
const release = JSON.parse(await readFile(path.join(proof, "release-package-report.json"), "utf8"));
assert.equal(hash(await readFile(path.join(root, ...release.packagePath.split("/")))), release.packageSha256);
const candidate = JSON.parse(await readFile(path.join(proof, "release-candidate.json"), "utf8"));
assert.equal(candidate.package.sha256, release.packageSha256);
const report = { kind: "d07-e-final-checks", checks, completeTasks: 9, installedByteMatchedFiles: audit.files.length,
  packageSha256: release.packageSha256, boundary: "Author Apply evidence only; independent review is next." };
await writeFile(path.join(proof, "final-checks-report.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
process.stdout.write(JSON.stringify({ checks: checks.map((item) => [item.id, item.code]),
  completeTasks: 9, packageSha256: release.packageSha256 }) + "\n");
