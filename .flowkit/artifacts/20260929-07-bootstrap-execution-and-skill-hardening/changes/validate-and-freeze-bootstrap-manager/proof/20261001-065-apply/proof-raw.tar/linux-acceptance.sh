#!/bin/sh
set -eu

apt-get update -qq
apt-get install -y -qq --no-install-recommends git ca-certificates

echo '=== Linux identity ==='
uname -sm
ldd --version | head -n 1
node --version
npm --version
git --version
node /flowkit-home/tools/openspec/1.10.0/bin/openspec.js --version

echo '=== Package identity and production install ==='
echo '1b2c88c9263d5892946d3d9aacba79a6392eb3d8b3b37fa3c87aebcc1550cba0  /release/flowkit-next-0.1.0.tgz' | sha256sum -c -
mkdir -p /work/install /work/target /work/harness/tests/acceptance
npm install --prefix /work/install --omit=dev --no-audit --no-fund /release/flowkit-next-0.1.0.tgz
test ! -e /work/install/node_modules/tsx
test ! -e /work/install/node_modules/typescript
node -e 'const m=require("/work/install/node_modules/flowkit-next/package.json"); if(m.name!=="flowkit-next"||m.version!=="0.1.0"||m.bin.flowkit!=="dist/cli/entrypoint.js") process.exit(1); console.log(JSON.stringify({name:m.name,version:m.version,bin:m.bin,dependencies:m.dependencies}))'

cli=/work/install/node_modules/flowkit-next/dist/cli/entrypoint.js
printf '%s\n' '{"repositoryRoot":"/work/target","flowkitHome":"/flowkit-home"}' > /work/query.json
echo '=== Missing OpenSpec root ==='
node "$cli" doctor --input /work/query.json > /work/fresh-doctor.json
node -e 'const d=require("/work/fresh-doctor.json"); if(d.status!=="fail"||d.diagnostics.find(x=>x.id==="openspec-root")?.status!=="fail") process.exit(1); console.log(JSON.stringify(d))'
set +e
node "$cli" status --input /work/query.json > /work/fresh-status.json
fresh_status_code=$?
set -e
test "$fresh_status_code" -eq 2
node -e 'const d=require("/work/fresh-status.json"); if(d.error?.kind!=="openspec-root-mismatch") process.exit(1); console.log(JSON.stringify(d))'

echo '=== Exact OpenSpec initialization and installed queries ==='
(cd /work/target && node /flowkit-home/tools/openspec/1.10.0/bin/openspec.js init --tools none)
node "$cli" doctor --input /work/query.json > /work/doctor.json
node "$cli" status --input /work/query.json > /work/status.json
node "$cli" next --input /work/query.json > /work/next.json
node -e 'for(const [f,v] of [["doctor","pass"],["status","idle"],["next","idle"]]){const d=require("/work/"+f+".json");if(d.status!==v)process.exit(1);console.log(JSON.stringify({kind:f,status:d.status}))}'
node "$cli" memo list --repository-root /work/target --input /work/query.json > /work/memo.json
node -e 'const d=require("/work/memo.json"); if(d.status!=="completed"||!Array.isArray(d.memos))process.exit(1);console.log(JSON.stringify({command:d.command,status:d.status,memos:d.memos.length}))'

echo '=== Detached acceptance against installed manager ==='
cp /source/tests/acceptance/foundation-manager.acceptance.test.ts /work/harness/tests/acceptance/
cp /source/tests/acceptance/foundation-manager-fixture.ts /work/harness/tests/acceptance/
printf '%s\n' '{"private":true,"type":"module"}' > /work/harness/package.json
npm install --prefix /work/harness --no-save --no-audit --no-fund tsx@4.23.12
cd /work/harness
FLOWKIT_HOME=/flowkit-home FLOWKIT_ACCEPTANCE_INSTALLATION=/work/install/node_modules/flowkit-next node --import tsx --test tests/acceptance/foundation-manager.acceptance.test.ts
