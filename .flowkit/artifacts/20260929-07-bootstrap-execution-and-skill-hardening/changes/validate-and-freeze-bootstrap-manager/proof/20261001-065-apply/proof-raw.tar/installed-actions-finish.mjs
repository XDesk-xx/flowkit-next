import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const proof = path.join(root, ".flowkit/artifacts/20260929-07-bootstrap-execution-and-skill-hardening/changes/validate-and-freeze-bootstrap-manager/proof/20261001-065-apply");
const installed = JSON.parse(await readFile(path.join(proof, "isolated-install-report.json"), "utf8"));
const fixture = path.join(installed.scratch, "action-fixture");
const target = path.join(fixture, "target");
const openspec = "C:/Users/xuser/.flowkit/tools/openspec/1.10.0/bin/openspec.js";
const home = "C:/Users/xuser/.flowkit";
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const checks = [];
async function run(id, executable, args, cwd, expectedCode = 0) {
  const start = new Date().toISOString();
  const child = spawn(executable, args, { cwd, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
  const stdout = [], stderr = [];
  child.stdout.on("data", (bytes) => stdout.push(bytes));
  child.stderr.on("data", (bytes) => stderr.push(bytes));
  const outcome = await new Promise((resolve) => {
    child.on("error", (error) => resolve({ code: null, signal: null, error: error.message }));
    child.on("close", (code, signal) => resolve({ code, signal, error: null }));
  });
  const out = Buffer.concat(stdout), err = Buffer.concat(stderr);
  await writeFile(path.join(proof, `${id}.stdout.txt`), out, { flag: "wx" });
  await writeFile(path.join(proof, `${id}.stderr.txt`), err, { flag: "wx" });
  checks.push({ id, command: [executable, ...args], cwd, start, end: new Date().toISOString(), ...outcome,
    stdoutBytes: out.length, stdoutSha256: hash(out), stderrBytes: err.length, stderrSha256: hash(err) });
  assert.equal(outcome.code, expectedCode, `${id}: ${err.toString("utf8")} ${out.toString("utf8")}`);
  const text = out.toString("utf8");
  try { return JSON.parse(text); } catch { return text; }
}
const base = { repositoryRoot: target, flowkitHome: home, deliveryId: "delivery-one", changeId: "change-one" };
const request = async (name, value) => {
  const file = path.join(fixture, `${name}.json`);
  await writeFile(file, JSON.stringify(value) + "\n", { flag: "wx" });
  return file;
};
const before = JSON.parse(await readFile(path.join(proof, "action-before-next.stdout.txt"), "utf8"));
const conflict = JSON.parse(await readFile(path.join(proof, "action-conflict.stdout.txt"), "utf8"));
const started = JSON.parse(await readFile(path.join(proof, "action-start.stdout.txt"), "utf8"));
const partial = JSON.parse(await readFile(path.join(proof, "action-partial-next-reprobe.stdout.txt"), "utf8"));
const missing = JSON.parse(await readFile(path.join(proof, "action-missing-proof.stdout.txt"), "utf8"));
assert.equal(missing.error?.kind, "proof-invalid");
const runId = started.runId;
const proofPath = `.flowkit/artifacts/delivery-one/changes/change-one/proof/${runId}/proof.txt`;
const bytes = await readFile(path.join(target, proofPath));
const result = JSON.parse(await readFile(path.join(fixture, "action-finish-missing-proof.json"), "utf8")).result;
result.facts.proofRefs = [{ path: proofPath, bytes: bytes.length, sha256: hash(bytes), deliveryId: "delivery-one", changeId: "change-one", runId, purpose: "synthetic fixture failure evidence" }];
const finishInput = await request("action-finish-input", { ...base, runId, role: "author", terminal: true, result });
const finished = await run("action-finish", process.execPath, [installed.cli, "action", "finish", "--input", finishInput], target);
assert.equal(finished.effect, "confirmed");
const after = await run("action-after-next", process.execPath, [installed.cli, "next", "--input", query], target);
assert.equal(after.decision?.kind, "blocked");
const report = { kind: "d07-e-installed-fixed-action-fixture", target, manager: installed.manager,
  packageSha256: installed.packageSha256, before, conflict, started, partial, missing, finished, after, checks,
  limitation: "Synthetic fixture only. A terminal FAIL tests persistence; it is not a real business verdict or independent review." };
await writeFile(path.join(proof, "installed-actions-report.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
process.stdout.write(JSON.stringify({ before: before.decision, started: started.effect, partial: partial.decision,
  missing: missing.error, finished: finished.effect, after: after.decision }) + "\n");
