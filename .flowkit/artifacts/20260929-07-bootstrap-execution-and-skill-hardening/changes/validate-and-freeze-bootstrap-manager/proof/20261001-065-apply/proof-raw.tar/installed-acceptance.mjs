import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const proof = path.join(root, ".flowkit/artifacts/20260929-07-bootstrap-execution-and-skill-hardening/changes/validate-and-freeze-bootstrap-manager/proof/20261001-065-apply");
const installed = JSON.parse(await readFile(path.join(proof, "isolated-install-report.json"), "utf8"));
const pnpm = "C:/nvm4w/nodejs/node_modules/corepack/dist/pnpm.js";
const command = [process.execPath, pnpm, "test:acceptance"];
const start = new Date().toISOString();
const child = spawn(command[0], command.slice(1), { cwd: root, windowsHide: true,
  env: { ...process.env, FLOWKIT_ACCEPTANCE_INSTALLATION: installed.manager }, stdio: ["ignore", "pipe", "pipe"] });
const stdout = [], stderr = [];
child.stdout.on("data", (bytes) => stdout.push(bytes));
child.stderr.on("data", (bytes) => stderr.push(bytes));
const code = await new Promise((resolve, reject) => { child.on("error", reject); child.on("close", resolve); });
const out = Buffer.concat(stdout), err = Buffer.concat(stderr);
await writeFile(path.join(proof, "installed-acceptance.stdout.txt"), out, { flag: "wx" });
await writeFile(path.join(proof, "installed-acceptance.stderr.txt"), err, { flag: "wx" });
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
const report = { kind: "d07-e-installed-acceptance", command, cwd: root, start, end: new Date().toISOString(), code,
  installation: installed.manager, packageSha256: installed.packageSha256, flowkitHome: process.env.FLOWKIT_HOME,
  stdoutBytes: out.length, stdoutSha256: sha(out), stderrBytes: err.length, stderrSha256: sha(err),
  limitation: "Windows host and simulated Windows compatibility cases; this is not Linux x64 glibc acceptance." };
await writeFile(path.join(proof, "installed-acceptance-report.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
assert.equal(code, 0, err.toString("utf8"));
process.stdout.write(JSON.stringify(report) + "\n");
