import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const proof = path.join(root, ".flowkit/artifacts/20260929-07-bootstrap-execution-and-skill-hardening/changes/validate-and-freeze-bootstrap-manager/proof/20261001-065-apply");
const scratch = path.join(root, ".tmp/d07-e-065-isolated");
const install = path.join(scratch, "installation");
const target = path.join(scratch, "target");
const home = "C:/Users/xuser/.flowkit";
const npm = "C:/nvm4w/nodejs/node_modules/npm/bin/npm-cli.js";
const openspec = path.join(home, "tools/openspec/1.10.0/bin/openspec.js");
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const checks = [];
async function run(id, executable, args, cwd, expectedCode = 0) {
  const start = new Date().toISOString();
  const child = spawn(executable, args, { cwd, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
  const stdout = [], stderr = [];
  child.stdout.on("data", (bytes) => stdout.push(bytes));
  child.stderr.on("data", (bytes) => stderr.push(bytes));
  const outcome = await new Promise((resolve) => {
    child.on("error", (error) => resolve({ exitCode: null, signal: null, processError: error.message }));
    child.on("close", (exitCode, signal) => resolve({ exitCode, signal, processError: null }));
  });
  const out = Buffer.concat(stdout), err = Buffer.concat(stderr);
  await writeFile(path.join(proof, `${id}.stdout.txt`), out, { flag: "wx" });
  await writeFile(path.join(proof, `${id}.stderr.txt`), err, { flag: "wx" });
  checks.push({ id, command: [executable, ...args], cwd, start, end: new Date().toISOString(), ...outcome,
    stdoutBytes: out.length, stdoutSha256: hash(out), stderrBytes: err.length, stderrSha256: hash(err) });
  assert.equal(outcome.exitCode, expectedCode, `${id}: ${err.toString("utf8")}`);
  const text = out.toString("utf8");
  try { return JSON.parse(text); } catch { return text; }
}
const release = JSON.parse(await readFile(path.join(proof, "release-package-report.json"), "utf8"));
const tgz = path.join(root, ...release.packagePath.split("/"));
assert.equal(hash(await readFile(tgz)), release.packageSha256);




const manager = path.join(install, "node_modules/flowkit-next");
const metadata = JSON.parse(await readFile(path.join(manager, "package.json"), "utf8"));
assert.equal(metadata.name, release.name);
assert.equal(metadata.version, release.version);
assert.equal(metadata.bin.flowkit, release.bin.flowkit);
assert.deepEqual(metadata.dependencies, release.dependencies);
const installed = await readdir(path.join(install, "node_modules"));
assert.ok(installed.includes("yaml"));
assert.ok(!installed.includes("tsx") && !installed.includes("typescript"));
const cli = path.join(manager, metadata.bin.flowkit);
for (const relative of ["docs/onboarding.md", "skills/actions/apply/SKILL.md", "skills/delivery/repository-integration/references/git-host.mjs", "skills/tools/openspec/SKILL.md", "config/tools/toolchain.lock.json"])
  assert.ok((await readFile(path.join(manager, relative))).length > 0, relative);
const query = path.join(scratch, "query.json");
await writeFile(query, JSON.stringify({ repositoryRoot: target, flowkitHome: home }) + "\n");
const freshStatus = await run("fresh-status-reprobe", process.execPath, [cli, "status", "--input", query], target, 2);
const freshDoctor = await run("fresh-doctor", process.execPath, [cli, "doctor", "--input", query], target);
assert.equal(freshStatus.error?.kind, "openspec-root-mismatch");
assert.equal(freshDoctor.status, "fail");
assert.equal(freshDoctor.diagnostics.find((item) => item.id === "openspec-root")?.status, "fail");
await run("openspec-init", process.execPath, [openspec, "init", "--tools", "none"], target);
const doctor = await run("initialized-doctor", process.execPath, [cli, "doctor", "--input", query], target);
const status = await run("initialized-status", process.execPath, [cli, "status", "--input", query], target);
const next = await run("initialized-next", process.execPath, [cli, "next", "--input", query], target);
assert.equal(doctor.status, "pass");
assert.equal(status.status, "idle");
assert.equal(next.status, "idle");
const report = { kind: "d07-e-065-isolated-install", scratch, install, manager, target, cli,
  packageSha256: release.packageSha256, installedTopLevel: installed, freshStatus, freshDoctor, doctor, status, next, checks,
  limitation: "Same-session isolated fixture on Windows; no real independent target, reviewer cycle, or new Agent session." };
await writeFile(path.join(proof, "isolated-install-report.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
process.stdout.write(JSON.stringify({ manager, packageSha256: release.packageSha256, doctor: doctor.status, status: status.status, next: next.status }) + "\n");
