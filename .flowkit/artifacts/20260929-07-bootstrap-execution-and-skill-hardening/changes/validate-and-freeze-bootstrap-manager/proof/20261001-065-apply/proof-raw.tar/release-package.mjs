import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { readdir, readFile, stat, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const proof = path.join(root, ".flowkit/artifacts/20260929-07-bootstrap-execution-and-skill-hardening/changes/validate-and-freeze-bootstrap-manager/proof/20261001-065-apply");
const pnpm = "C:/nvm4w/nodejs/node_modules/corepack/dist/pnpm.js";
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
async function command(id, executable, args, cwd = root) {
  const start = new Date().toISOString();
  const child = spawn(executable, args, { cwd, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
  const stdout = [], stderr = [];
  child.stdout.on("data", (bytes) => stdout.push(bytes));
  child.stderr.on("data", (bytes) => stderr.push(bytes));
  const { exitCode, signal, error } = await new Promise((resolve) => {
    child.on("error", (failure) => resolve({ exitCode: null, signal: null, error: failure.message }));
    child.on("close", (code, signal) => resolve({ exitCode: code, signal, error: null }));
  });
  const out = Buffer.concat(stdout), err = Buffer.concat(stderr);
  await writeFile(path.join(proof, `${id}.stdout.txt`), out, { flag: "wx" });
  await writeFile(path.join(proof, `${id}.stderr.txt`), err, { flag: "wx" });
  const record = { id, command: [executable, ...args], cwd, start, end: new Date().toISOString(), exitCode, signal, error,
    stdoutBytes: out.length, stdoutSha256: hash(out), stderrBytes: err.length, stderrSha256: hash(err) };
  assert.equal(exitCode, 0, `${id}: ${err.toString("utf8") || error}`);
  return { record, stdout: out };
}
const checkReport = JSON.parse(await readFile(path.join(proof, "verified-checks-report.json"), "utf8"));
assert.ok(checkReport.checks.every((check) => check.exitCode === 0), "candidate checks must pass before pack");
const pack = await command("pack", process.execPath, [pnpm, "pack", "--pack-destination", proof]);
const packageJson = JSON.parse(await readFile(path.join(root, "package.json"), "utf8"));
const packageName = `${packageJson.name}-${packageJson.version}.tgz`;
const packagePath = path.join(proof, packageName);
const packageBytes = await readFile(packagePath);
const members = await command("package-members", "tar", ["-tzf", packagePath]);
const memberNames = members.stdout.toString("utf8").trim().split(/\r?\n/).map((value) => value.replaceAll("\\", "/"));
const memberSet = new Set(memberNames);
for (const required of ["package/package.json", "package/dist/cli/entrypoint.js", "package/dist/domain/index.js",
  "package/docs/onboarding.md", "package/config/tools/toolchain.lock.json", "package/skills/actions/apply/SKILL.md",
  "package/skills/delivery/start/SKILL.md", "package/skills/tools/openspec/SKILL.md",
  "package/skills/vendors/openspec/README.md"]) assert.ok(memberSet.has(required), `package missing ${required}`);
async function filesAt(directory) {
  const names = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) names.push(...await filesAt(full));
    else if (entry.isFile()) names.push(path.relative(root, full).replaceAll("\\", "/"));
  }
  return names;
}
const skillFiles = (await filesAt(path.join(root, "skills"))).filter((name) =>
  ["skills/actions/", "skills/delivery/", "skills/tools/openspec/", "skills/vendors/openspec/"].some((prefix) => name.startsWith(prefix)));
for (const file of skillFiles) assert.ok(memberSet.has(`package/${file}`), `package missing ${file}`);
const record = { kind: "d07-e-release-package", name: packageJson.name, version: packageJson.version,
  bin: packageJson.bin, dependencies: packageJson.dependencies, packagePath: path.relative(root, packagePath).replaceAll("\\", "/"),
  packageBytes: packageBytes.length, packageSha256: hash(packageBytes), packageMemberCount: memberNames.length,
  sourceSkillCount: skillFiles.length, commands: [pack.record, members.record] };
await writeFile(path.join(proof, "release-package-report.json"), JSON.stringify(record, null, 2) + "\n", { flag: "wx" });
assert.equal((await stat(packagePath)).size, packageBytes.length);
process.stdout.write(JSON.stringify(record) + "\n");
