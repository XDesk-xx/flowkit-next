import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const proof = path.join(root, ".flowkit/artifacts/20260929-07-bootstrap-execution-and-skill-hardening/changes/validate-and-freeze-bootstrap-manager/proof/20261001-065-apply");
const scratch = path.join(root, ".tmp/d07-e-065-linux-02");
const home = "C:/Users/xuser/.flowkit";
const image = "node:22.23.2-bookworm-slim";
const release = JSON.parse(await readFile(path.join(proof, "release-package-report.json"), "utf8"));
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
assert.equal(sha(await readFile(path.join(root, ...release.packagePath.split("/")))), release.packageSha256);
await mkdir(scratch, { recursive: false });
const args = ["run", "--rm",
  "--mount", `type=bind,source=${proof},target=/release,readonly`,
  "--mount", `type=bind,source=${root},target=/source,readonly`,
  "--mount", `type=bind,source=${home},target=/flowkit-home,readonly`,
  "--mount", `type=bind,source=${scratch},target=/work`,
  image, "sh", "/release/linux-acceptance-02.sh"];
const start = new Date().toISOString();
const child = spawn("docker", args, { cwd: root, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
const stdout = [], stderr = [];
child.stdout.on("data", (bytes) => stdout.push(bytes));
child.stderr.on("data", (bytes) => stderr.push(bytes));
const outcome = await new Promise((resolve) => {
  child.on("error", (error) => resolve({ code: null, signal: null, error: error.message }));
  child.on("close", (code, signal) => resolve({ code, signal, error: null }));
});
const out = Buffer.concat(stdout), err = Buffer.concat(stderr);
await writeFile(path.join(proof, "linux-acceptance-02.stdout.txt"), out, { flag: "wx" });
await writeFile(path.join(proof, "linux-acceptance-02.stderr.txt"), err, { flag: "wx" });
const report = { kind: "d07-e-linux-x64-glibc-detached-acceptance", image, command: ["docker", ...args],
  start, end: new Date().toISOString(), ...outcome, packageSha256: release.packageSha256,
  scratch, stdoutBytes: out.length, stdoutSha256: sha(out), stderrBytes: err.length, stderrSha256: sha(err),
  scope: "Installed package and exact managed OpenSpec on Linux x64 glibc; TS acceptance harness copied separately with tsx." };
await writeFile(path.join(proof, "linux-acceptance-02-report.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
assert.equal(outcome.code, 0, err.toString("utf8"));
process.stdout.write(JSON.stringify({ code: outcome.code, image, packageSha256: release.packageSha256,
  stdoutBytes: out.length, stderrBytes: err.length }) + "\n");
