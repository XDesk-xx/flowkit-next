import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const proof = path.join(root, ".flowkit/artifacts/20260929-07-bootstrap-execution-and-skill-hardening/changes/validate-and-freeze-bootstrap-manager/proof/20261001-065-apply");
const installed = JSON.parse(await readFile(path.join(proof, "isolated-install-report.json"), "utf8"));
const target = path.join(installed.scratch, "action-fixture/target");
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
async function run(id, args, expectedCode) {
  const start = new Date().toISOString();
  const child = spawn(process.execPath, [installed.cli, ...args], { cwd: target, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
  const stdout = [], stderr = [];
  child.stdout.on("data", (bytes) => stdout.push(bytes));
  child.stderr.on("data", (bytes) => stderr.push(bytes));
  const code = await new Promise((resolve, reject) => { child.on("error", reject); child.on("close", resolve); });
  const out = Buffer.concat(stdout), err = Buffer.concat(stderr);
  await writeFile(path.join(proof, `${id}.stdout.txt`), out, { flag: "wx" });
  await writeFile(path.join(proof, `${id}.stderr.txt`), err, { flag: "wx" });
  assert.equal(code, expectedCode, `${id}: ${err.toString("utf8")}`);
  return { id, command: [process.execPath, installed.cli, ...args], cwd: target, start, end: new Date().toISOString(), code,
    stdoutBytes: out.length, stdoutSha256: hash(out), stderrBytes: err.length, stderrSha256: hash(err), result: JSON.parse(out.toString("utf8")) };
}
const input = path.join(installed.scratch, "support-checked-input.json");
const conflictInput = path.join(installed.scratch, "support-conflict-input.json");
await writeFile(input, JSON.stringify({ repositoryRoot: target, flowkitHome: "C:/Users/xuser/.flowkit" }) + "\n", { flag: "wx" });
await writeFile(conflictInput, JSON.stringify({ repositoryRoot: installed.target, flowkitHome: "C:/Users/xuser/.flowkit" }) + "\n", { flag: "wx" });
const legal = await run("support-memo-list", ["memo", "list", "--repository-root", target, "--input", input], 0);
const conflict = await run("support-conflict", ["memo", "list", "--repository-root", target, "--input", conflictInput], 2);
assert.equal(legal.result.status, "completed");
assert.deepEqual(legal.result.memos, []);
assert.equal(conflict.result.error?.kind, "invalid-request");
const report = { kind: "d07-e-installed-fixed-support", packageSha256: installed.packageSha256, target, legal, conflict,
  limitation: "Synthetic isolated fixture; no Owner authorization for mutation is inferred." };
await writeFile(path.join(proof, "installed-support-report.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
process.stdout.write(JSON.stringify({ legal: legal.result.status, conflict: conflict.result.error?.kind }) + "\n");
