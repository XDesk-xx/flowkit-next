import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, readdir, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const proof = path.join(root, ".flowkit/artifacts/20260929-07-bootstrap-execution-and-skill-hardening/changes/validate-and-freeze-bootstrap-manager/proof/20261001-065-apply");
const installed = JSON.parse(await readFile(path.join(proof, "isolated-install-report.json"), "utf8"));
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
async function filesAt(directory) {
  const names = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) names.push(...await filesAt(file));
    else if (entry.isFile()) names.push(file);
  }
  return names;
}
const relative = ["docs/onboarding.md", "config/tools/toolchain.lock.json"];
for (const directory of ["dist", "skills/actions", "skills/delivery", "skills/tools/openspec", "skills/vendors/openspec"])
  relative.push(...(await filesAt(path.join(root, directory))).map((file) => path.relative(root, file).replaceAll("\\", "/")));
const files = [];
for (const name of relative.sort()) {
  const source = await readFile(path.join(root, name));
  const packageFile = await readFile(path.join(installed.manager, name));
  assert.deepEqual(packageFile, source, `installed bytes differ: ${name}`);
  files.push({ path: name, bytes: source.length, sha256: hash(source) });
}
const report = { kind: "d07-e-installed-byte-audit", packageSha256: installed.packageSha256,
  installedManager: installed.manager, files, verifiedFileCount: files.length };
await writeFile(path.join(proof, "installed-byte-audit-report.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
process.stdout.write(JSON.stringify({ verifiedFileCount: files.length, packageSha256: installed.packageSha256 }) + "\n");
